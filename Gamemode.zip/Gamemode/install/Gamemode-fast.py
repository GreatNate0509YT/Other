import time
import keyboard
import pyautogui
pyautogui.press("win")
time.sleep(1)
keyboard.press("s+e+t+t+i+n+g+s")
time.sleep(1)
keyboard.press("enter")
time.sleep(1)
keyboard.press("g+a+m+e+m+o+d+e")
time.sleep(1)
keyboard.press("enter")
time.sleep(1)
keyboard.press("tab")
time.sleep(1)
keyboard.press_and_release("enter")
time.sleep(1)
keyboard.press_and_release("space")

